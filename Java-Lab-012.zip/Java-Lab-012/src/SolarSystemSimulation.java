
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Integer.parseInt;

public class SolarSystemSimulation {
        public static void main(String[] args) {
            Simulation simulation = new Simulation();
            simulation.run();
        }
    }

    class Simulation {
        public void run() {
            SolarSystem solarSystem = new SolarSystem();
            solarSystem.addSun(new Sun("Sun", 696340, 1.989 * Math.pow(10, 30), 5500));
            solarSystem.addPlanet(new Planet("Earth", 6371, 5.972 * Math.pow(10, 24), 149.6 * Math.pow(10, 6), 0, 29.78));
            solarSystem.showPlanets();
            solarSystem.movePlanets();
            solarSystem.showPlanets();
            Sun.more();


        }
    }

    class SolarSystem {
        private List<Planet> planets;
        private Sun theSun;

        public SolarSystem() {
            this.planets = new ArrayList<>();
            this.theSun = null;
        }

        public void addPlanet(Planet planet) {
            planets.add(planet);
        }

        public void addSun(Sun sun) {
            this.theSun = sun;
        }

        public void showPlanets() {
            System.out.println("Planets in the solar system:");
            for (Planet planet : planets) {
                System.out.println(planet);
            }
            System.out.println("Sun: " + theSun);
            System.out.println();
        }

        public void movePlanets() {
            double G = 0.1;
            double dt = 0.001;

            for(Planet p : this.planets) {
                p.moveTo(p.getXPos() + dt * p.getXVel(),
                        p.getYPos() + dt * p.getYVel());

                double rx = this.theSun.getXPos() - p.getXPos();
                double ry = this.theSun.getYPos() - p.getYPos();
                double r = Math.sqrt(Math.pow(rx, 2) + Math.pow(ry, 2));

                double accX = G * this.theSun.getMass() * rx / Math.pow(r, 3);
                double accY = G * this.theSun.getMass() * ry / Math.pow(r, 3);

                p.setXVel(p.getXVel() + dt * accX);
                p.setYVel(p.getYVel() + dt * accY);
            }
        }
    }

    class Planet {
        private String name;
        private double radius;
        private double mass;
        private double distance;
        private double x;
        private double y;
        private double velX;
        private double velY;

        public Planet(String name, double radius, double mass, double distance, double velX, double velY) {
            this.name = name;
            this.radius = radius;
            this.mass = mass;
            this.distance = distance;
            this.x = distance;
            this.y = 0;
            this.velX = velX;
            this.velY = velY;
        }

        public double getXPos() {
            return x;
        }

        public double getYPos() {
            return y;
        }

        public void moveTo(double newX, double newY) {
            this.x = newX;
            this.y = newY;
        }

        public double getXVel() {
            return velX;
        }

        public double getYVel() {
            return velY;
        }

        public void setXVel(double newVelX) {
            this.velX = newVelX;
        }

        public void setYVel(double newVelY) {
            this.velY = newVelY;
        }

        @Override
        public String toString() {
            return name + " [Position: (" + x + ", " + y + "), Velocity: (" + velX + ", " + velY + ")]";
        }
    }

    class Sun {
        private String name;
        private double radius;
        private double mass;
        private double temp;
        private double x;
        private double y;

        public Sun(String name, double radius, double mass, double temp) {
            this.name = name;
            this.radius = radius;
            this.mass = mass;
            this.temp = temp;
            this.x = 0;
            this.y = 0;
        }

        public double getXVel() {
            return 0;  // Sun is stationary in this simulation
        }

        public double getYVel() {
            return 0;
        }

        public double getMass() {
            return mass;
        }

        @Override
        public String toString() {
            return name + " [Mass: " + mass + ", Temperature: " + temp + "]";
        }
        public double getXPos() {
            return x;
        }

        public double getYPos() {
            return y;
        }

        public static void more(){
            Scanner s = new Scanner(System.in);
            int planets = 1;

            SolarSystem SSystem = new SolarSystem();
            while(true){
                System.out.println("What would you like to simulate? \n 1) Add a new Planet \n 2) Move Planets \n " +
                        "3)Show planets' location, velocity, and distance from the sun \n 4) Quit");
                switch (parseInt(s.nextLine())) {
                    case 1:
                        //Planet(String name, double radius, double mass, double distance, double velX, double velY)
                        System.out.println("What is the name of your new planet?");
                        String name = s.nextLine();
                        System.out.println("What is your planet's radius?");
                        double radius = parseInt(s.nextLine());
                        System.out.println("What is your planet's mass?");
                        double mass = parseInt(s.nextLine());
                        System.out.println("What is your planet's distance from the sun?");
                        double distance = parseInt(s.nextLine());
                        System.out.println("What is your planet's velocity in x?");
                        double velX = parseInt(s.nextLine());
                        System.out.println("What is your planet's velocity in y?");
                        double velY = parseInt(s.nextLine());
                        Planet Name = new Planet(name, radius, mass, distance, velX, velY);
                        SSystem.addPlanet(Name);
                        planets++;
                        System.out.println("There are " + planets + " planets and one sun.");
                        break;

                    case 2: SSystem.movePlanets();
                    break;
                    case 3: SSystem.showPlanets();
                    break;
                    case 4: System.exit(0);

                }

            }
        }
    }


/**
 *
 */

